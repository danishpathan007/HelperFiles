# FaceTracking
How to Create a Face Expression Recognizer With TrueDepth Camera in Swift

## Introduction
Two years ago, with iPhone X, Apple introduced a new kind of camera and biometric device. Called TrueDepth Camera, it contains a dot infrared projector that recognizes you by mapping your face with 30,000 invisible dots. Thanks to this accuracy, we can also recognize different facial movements. Today I'll show you how simple it is!

## Full article [HERE](https://medium.com/p/7ddef0db51de)
