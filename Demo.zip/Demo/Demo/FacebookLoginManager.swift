//
//  FacebookLoginManager.swift
//  GroceryList
//
//  Created by zapbuild on 28/05/19.
//  Copyright © 2019 zapbuild. All rights reserved.
//

import Foundation
import FBSDKCoreKit
import FBSDKLoginKit
import SwiftyJSON

protocol SocialLoginManagerDelegate {
    
    func socialLoginSuccess(socialType: Constants.SocialType)
    func socialLoginFailed(_ error:Error?, isCancelled:Bool, socialType: Constants.SocialType )
    func didSocialLogout(socialType: Constants.SocialType )
    
}

class FacebookLoginManager: NSObject {
    
    private var delegate: SocialLoginManagerDelegate?

    init(delegate: SocialLoginManagerDelegate?) {
    super.init()
        self.delegate = delegate
    }
    
    /**
     Login to facebook and return access token
     */
    func login(requestParameters:[String], controller: UIViewController) {
        LoginManager().logOut()
//        if let token = AccessToken.current?.tokenString {
//            delegate?.socialLoginSuccess(token: token, socialType: .facebook, user: nil)
//            return
//        }
        LoginManager().logIn(permissions: requestParameters, from: controller) { (result, error) in
            //Check for error
            if error != nil {
                self.delegate?.socialLoginFailed(error, isCancelled: false, socialType: .facebook)
                return
            }
            //Check for cancelled by user
            if (result?.isCancelled ?? true) {
                self.delegate?.socialLoginFailed(error, isCancelled: true, socialType: .facebook)
                return
            }
            //Check token
            guard  let token = result?.token?.tokenString else {
                self.delegate?.socialLoginFailed(nil, isCancelled: false, socialType: .facebook)
                return
            }
           self.getUserData(parameters: Constants.FacebookParameter.parameters) { (data, error) in
                if let data = data {
                    let json =  JSON(data)
                    //Save user data here
                    let name = json["name"].string
                    let socialId = json["id"].string
                    let email = json["email"].string
                    
                    print(name)
                    print(email)
                    print(socialId)


                   // UserDefaultManager().managePreviousUserDataAfterLogin(email: email, socialId: socialId)
                    
//                    _ = User.set(id: Constants.DefaultId.LoggedUser.id, email: email, name: name, isSocial: false, picture: nil, pictureUrl: nil, socialId: socialId, socialToken: token)
                    self.delegate?.socialLoginSuccess(socialType: .facebook)
                }
             }
        }
    }
    
    /**
     Logout from facebook
     */
    func logout() {
        LoginManager().logOut()
        delegate?.didSocialLogout(socialType: .facebook)
    }
    
    /**
     Return user data of facebook user
     */
  private  func getUserData(parameters: [String:Any], completion:@escaping (Any?,Error?)->()) {
        //If access token is nil than dont check for user data
        if AccessToken.current == nil {
            completion(nil,nil)
            return
        }
        let graphRequest = GraphRequest(graphPath: "/me", parameters: parameters)
        graphRequest.start { (connection, data, error) in
            //Check for error
            if error != nil {
                completion(nil,error)
                return
            }
            //If no error return Data
            completion(data,nil)
        }
    }
}
