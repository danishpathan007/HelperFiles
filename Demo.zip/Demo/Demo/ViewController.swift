//
//  ViewController.swift
//  Demo
//
//  Created by Danish on 16/01/22.
//

import UIKit
import FacebookLogin
import GoogleSignIn

class ViewController: UIViewController {

    private var socialLoginManager: SocialLoginManager?

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        socialLoginManager = SocialLoginManager(delegate: self)
        
    }
    
    /**
     Facebook login
     */
    @IBAction private func facebookLoginButtonAction(_ sender: UIButton) {
        socialLoginManager?.login(to: .facebook, controller: self)
    }

    @IBAction func googleButtonAction(_ sender:UIButton){
        let signInConfig = GIDConfiguration.init(clientID: "792241066811-1id94gl4bsdbet3plj67kmpp5f3eoc0m.apps.googleusercontent.com")
        
        GIDSignIn.sharedInstance.signIn(with: signInConfig, presenting: self) { user, error in
            guard error == nil else { return }
            guard let user = user else { return }

            let emailAddress = user.profile?.email

            let fullName = user.profile?.name
            let givenName = user.profile?.givenName
            let familyName = user.profile?.familyName

            let profilePicUrl = user.profile?.imageURL(withDimension: 320)
            
            print(fullName)
            print(givenName)
            print(familyName)
            print(emailAddress)
        }

    }

}


//MARK:-  Social login manager delegates
extension ViewController: SocialLoginManagerDelegate {
    /**
     On Logout
     */
    func didSocialLogout(socialType: Constants.SocialType) {
        //Logger.log("Logged out from\(socialType)")
    }
    
    /**
     On Login Success
     */
    func socialLoginSuccess(socialType: Constants.SocialType) {
//        signUpViewModel.signUp(webServiceManager: webserviceManager, socialLoginType: socialType) { (error, successMessage) in
//            UserDefaultManager().set(socialLoginType: socialType)
//            InitialScreenManager.shared.showDashboardScreen()
//        }
    }
    
    /**
     On Login Failed
     */
    func socialLoginFailed(_ error: Error?, isCancelled: Bool, socialType: Constants.SocialType) {
        //AlertUtility.showAlert(self, title: Constants.AlertTitle.error, message: Constants.ValidationMessages.loginFailed)
    }
    
}
