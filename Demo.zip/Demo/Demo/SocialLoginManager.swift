//
//  SocialLoginManager.swift
//  GroceryList
//
//  Created by zapbuild on 29/05/19.
//  Copyright © 2019 zapbuild. All rights reserved.
//

import Foundation
import UIKit


class SocialLoginManager: NSObject {
    
    var delegate: SocialLoginManagerDelegate?
    
    
    private var facebookLoginManager: FacebookLoginManager?
    
    init(delegate: SocialLoginManagerDelegate?) {
        super.init()
        self.delegate = delegate
        facebookLoginManager = FacebookLoginManager(delegate: delegate)
    }
    
    deinit {
        //Logger.log("Goinnnnn")
    }
    
    /**
     Login to social account
    Implement SocialLoginManager delegate for tracking responses
     */
    func login(to socialType: Constants.SocialType, controller: UIViewController) {
        switch socialType {
        case .facebook:
    facebookLoginManager?.login(requestParameters:Constants.FacebookParameter.permissions, controller: controller)
        case .google:
            //googleLoginManager?.login(uiDelegate: controller as! GIDSignInUIDelegate)
            break
        default: break
        }
    }
    
    /**
     Logout from social account
     Implement SocialLoginManager delegate for tracking responses
     */
    func logout(controller: UIViewController) {
        facebookLoginManager?.logout()

        // Get Social loging type form user default
//        guard let socialType = UserDefaultManager().getSocialLoginType() else { return }
//        switch socialType {
//        case .facebook: // Logout form facebook
//            facebookLoginManager?.logout()
//            User.delete(id: Constants.DefaultId.LoggedUser.id)
//        case .google: // Logout form google
////            googleLoginManager?.logout(uiDelegate: uiDelegate!)
////            User.delete(id: Constants.DefaultId.LoggedUser.id)
//            break
//        default: break
//        }
    }
    
    /**
     Get User detail
     */
//    func getUserDetail(from socialType: Constants.SocialType, completion:@escaping (User?, Error?)->()) {
//        switch socialType {
//        case .facebook:
//            FacebookLoginManager(delegate: nil).getUserData(parameters: Constants.FacebookParameter.parameters) { (data, error) in
//                var user: User?
//                if let data = data {
//                    user = User(json: JSON(data))
//                }
//                completion(user,error)
//            }
//        case .google:
//            completion(GoogleLoginManager(delegate: nil).getUserDetail(),nil)
//        }
//    }
}
