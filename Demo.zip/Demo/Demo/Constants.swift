//
//  Constants.swift
//  Hooty
//
//  Created by Sandeep Singh on 16/11/17.
//  Copyright © 2017 Zapbuild. All rights reserved.
//

import Foundation
import UIKit


class Constants: NSObject {
    
    
    struct AppColors {
        //TextColors
        struct  Text {
            static let orange: UIColor = #colorLiteral(red: 0.9816640019, green: 0.3344495296, blue: 0.1155330762, alpha: 1)
            static let gray: UIColor = .lightGray
            static let green = UIColor(red:80 / 255, green: 176 / 255, blue: 96 / 255, alpha: 1)
            static let red = UIColor(red:252 / 255, green: 52 / 255, blue: 52 / 255, alpha: 1)
        }
        
        struct StatusBar {
            static let whiteWith80 = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.8)
        }
    }
    
    enum TabBarIndex: Int {
        case list = 0
        case recipe
        case reminder
        case setting
        case upgrade
    }
    
    enum PopOverMenuOption: String {
        case selectEdit = "Select & Edit"
        case createList = "Create List"
        case duplicateList = "Duplicate List"
        case createFolder = "Create Folder"
        case folderSetting = "Folder Settings"
        case reorderDelete = "Reorder & Delete"
        case logout = "Logout"
        case createRecipe = "Create Recipe"
        case createCollection = "Create Colleciton"
        case selectDelete = "Select & Delete"
        //Used on Recent Items View Controller
        
        case addAllRecentItemsToList = "Add All Recent Items To List"
        case selectAndDeleteItems = "Select & Delete Items"
        case hideCategories = "Hide Categories"
        case filterList = "Filter List"
        
        //Used on add Items view controller
        case selectAndEditItems = "Select and edit items"
        case uncrossAll = "Not purchased all"
        case deleteCrossedItems = "Delete purchased items"
        case deleteAllItems = "Delete all items"
        case listSettings = "List settings"
        
        //Used on selected Items
        case addToFavorites = "Add to favorites"
        case assignStore = "Assign store"
        case moveItems = "Move items"
        case copyItems = "Copy items"
        case crossOffItems = "Purchased items"
        case uncrossItems = "Not purchased items"
        case deleteItems = "Delete items"
        
        // On favorite list
        case markAllUnfavorite = "Mark all unfavorite"
        case markAllFavorite = "Mark all favorite"
        case createAt = "By Date Created"
        case name = "By Name"
        case preparationTime = "By Preparation Time"
        case cookTime = "By Cook Time"
        
    }
    struct SegueIdentifier {
        static let reminderViewController = "pushReminderViewController"
        static let showSelectIcon = "showSelectIcon"
        static let presentAddReminder = "presentAddReminder"
        static let presentEditReminder = "editReminderSegue"
        static let upgradeViewControllerSegue = "upgradeViewControllerSegue"
        static let qrScanViewControllerSegue = "qrScanSegue"
        static let scannedCodeItemSegue = "scannedCodeItemSegue"
        static let upgradeViewSegue = "upgradeViewSegue"
        static let webViewSegue = "webViewSegue"
    }
    
    struct UserInteractionCounterLimit {
        struct FaceView {
            static let itemCrossedCount = 10
            static let itemAddedCount = 10
            static let recipeClicksCount = 3
        }
        
        struct RatingView {
            static let reminderAddedCount = 3
            static let ingredientAddedCount = 3
            static let newListCreatedCount = 1
        }
        struct FreeAccountLimit {
            static let listCreateLimit = 4
            static let reminderCreateLimit = 4
        }
    }
    
    
    class func openSettings() {
        UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!, completionHandler: nil)
    }
    
    
    
    enum RepeatType: String {
        case once = "Never"
        case day = "Daily"
        case month = "Monthly"
    }
    
    struct ListType {
        static let grocery      = "Gorcery"
        static let categorized  = "Categorzied"
        static let basic        = "Basic"
    }
    
    enum ListAction {
        case moveItems
        case copyItems
        case copyList
        case duplicateList
    }
    
    enum RecipeFilter: String {
        case createdAt = "created_at"
        case name = "name"
        case preparationTime = "preparation_time"
        case cookTime = "cook_time"
    }
    
    struct UserDefaultKey {
        static let socialType = "socialType"
        static let isLoggedIn = "isLoggedIn"
        static let user = "user"
        static let token = "token"
        static let socialUniqueId = "socialUniqueId"
        static let uniqueId = "uniqueId"
        static let createdReminderCount = "createdReminderCount"
         static let createdListCount = "createdListCount"
        static let dataUpdateTimeStamp = "dataUpdateTimeStamp"
        static let units = "units"
        static let items = "items"
        static let alreadyLaunched = "firstTimeLaunch"
         static let isGuest = "isGuest"
        static let listOrderIndex = "listOrderIndex"
        static let fcmToken = "fcmToken"
        static let interactionCounter = "interactionCounter"
    }
    
    struct CoreData {
        struct Entity {
            static let user = "User"
            static let store = "Store"
            static let item = "Item"
            static let list = "List"
            static let appSetting = "AppSettings"
            static let itemCategory = "ItemCategory"
            static let defaultItem = "DefaultItem"
            static let defaultIcon = "DefaultIcon"
            static let unit = "Unit"
            static let reminder = "Reminder"
            static let subscription = "Subscription"
            static let product = "Product"
        }
        
        struct Container {
            static let dataModelName = "GroceryList"
            static let persistentStoreName = "GroceryList"
        }
        
        struct ObjectFetchLimit {
            static let recnetItems = 100
        }
    }
    
    struct DefaultId {
        struct List {
            static let myGroceryList = "-1"
            static let favoriteList = "-2"
            static let recentList = "-3"
            static let all = [myGroceryList, favoriteList, recentList]
        }
        
        struct Icon {
            static let defaultCategoryIconId = "1"
            static let defaultStoreIconId = "-2"
        }
        
        struct Category {
            static let defaultCategoryId = "-1"
        }
        
        struct LoggedUser {
            static let id = "1"
        }
    }
    
    struct ListIcon {
        static let myGroceryList = #imageLiteral(resourceName: "listOrange")
        static let favorietList = #imageLiteral(resourceName: "listYellow")
        static let recentList = #imageLiteral(resourceName: "listGreen")
        static let defaultIcon = #imageLiteral(resourceName: "listOrange")
    }
    
    struct TableViewEdgeInset {
        static let bottom300 = UIEdgeInsets(top: 0, left: 0, bottom: 300, right: 0)
        static let bottom200 = UIEdgeInsets(top: 0, left: 0, bottom: 200, right: 0)
        static let bottom100  = UIEdgeInsets(top: 0, left: 0, bottom: 100, right: 0)
        
    }
    
    struct NotificationUtil {
        static let updateHomeListScreen = Notification.Name(rawValue: "UpdateHomeScreen")
        static let itemUpdatedInList = Notification.Name(rawValue: "ItemUpdatedInList")
        static let updatedReminderScreen =  Notification.Name(rawValue: "updatedReminderScreen")
        static let subscriptionStatusUpdated = Notification.Name(rawValue: "subscriptionStatusUpdated")
        static let showFaceRatingView = Notification .Name(rawValue:"showFaceRatingView")
        static let showReviewRatingView = Notification.Name(rawValue:"showReviewRatingView")
    }
    
    struct NotificationThreadId {
        static let reminder = "ReminderNotification"
    }
    
    
    struct ApiVersion {
        static let versionOne     = "v1"
        static let latestVersion  = ApiVersion.versionOne
    }
    
    enum BaseUrl : String {
        //case live = ""
        case qa = "http://grocery-qa.zapbuild.com:2020"
        case local = "http://grocery-qa.zapbuild.com:2019"//"http://grocery.zapbuild.com:2019"
        
        case live  = "http://18.216.131.97"
    }
    
    struct WebServicesApi {
        private static let prefix = BaseUrl.live.rawValue + "/api/\(ApiVersion.versionOne)"
        static let signup = prefix + "/users/sign_up"
        static let login = prefix + "/users/login"
        static let getProfile = prefix + "/users/profile"
        static let forgotPassword = prefix + "/users/forgot_password"
        static let changePassword = prefix + "/users/change_password"
        static let getAllDefaultData = prefix + "/dashboard/get_all_data"
        static let checkUpdatedData = prefix + "/dashboard/is_updated"
        static let getAllRecipies = prefix + "/recipes/get_all_recipes"
        static let getRecipe = prefix + "/recipes/get_recipe"
        static let saveSubscriptionData = prefix + "/subscriptions"
        static let getSubscriptionData = prefix + "/subscriptions"
        static let barCodeScan = "https://api.barcodelookup.com/v2/products"
        static let guestLogin = prefix + "/users/guest_login"
        
    }
    
    struct EmptyDataMessage {
        static let noList = "No Lists"
        static let noItem = "No Items"
        static let noItemRemaining = "No items remaining"
        static let noItemFound = "No items found"
        static let noCategory = "No Categories"
        static let noStore = "No Stores"
        static let noRecipe = "No Recipes"
        static let noReminder = "No Reminders"
    }
    
    
    
    struct AlertTitle{
        static let success = "Success"
        static let alert = "Alert"
        static let failed = "Failed"
        static let uncrossAll = "Not Purchased All"
        static let deleteAll = "Delete All"
        static let deleteCrossed = "Delete Purchased"
        static let error = "Error"
        static let delete = "Delete"
        static let passwrodNotSet = "Cannot change password"
        static let purchasedFail = "Purchased Failed"
        static let restorePurchaseFail = "Restore Failed"
        static let permissionDenied = "Permission Denied"
        static let noInternet = "No internet"
    }
    
    struct CheckTrueFalseString{
        static let isTrue = "true"
        static let isFalse = "false"
    }
    enum SocialType: String {
        case facebook = "facebook"
        case google = "google"
        case apple = "apple"
    }
    
    struct SocialKey {
        static let google = "AIzaSyDb4DoKslXi7ommSNjIdlinqNQg8K4Q1d0"
    }
    
    struct FacebookParameter {
        static let permissions = ["public_profile", "email"]
        static let parameters = ["fields":"id,first_name,last_name,middle_name,name,name_format,short_name,email"]
    }
    
    struct UserRolesIds{
        static let salesPersonId = 5
        static let clientId = 2
    }
    
    struct InputLengthConstraints {
        struct Minimum {
            
            static let password = 6
            static let driverLicense = 7
            static let phoneNumber = 10
            static let listName = 1
            static let itemName = 1
            
        }
        struct Maximum {
            
            static let userName = 100
            static let password = 20
            static let email = 50
            static let phoneNumber = 10
            static let name = 50
            static let listName = 50
            static let itemName = 50
            static let itemNotes = 300
            static let itemPrice = 12
            static let itemQuantity = 10
            static let year = 4
            static let broadcastTitle = 100
            static let description = 250
            static let budget = 12
            static let storeName = 50
            static let categoryName = 50
            static let minimumPrice = 10
            static let maximumPrice = 10
            static let reminderTitle = 50
            static let reminderNote = 300
            
        }
    }
    
    struct RegexPattern {
        static let onlyAlphabetsAneWhiteSpace = ".*[^A-Za-z ].*"
    }
    
    
    
    
    struct DateFormats {
        static let ddMMyyyy = "dd/MM/yyyy"
        static let HHmm = "HH:mm"
        static let ddMMyyyyHHmma = "dd/MM/yyyy hh:mm a"
    }
    
    struct NavigationControllerNames {
        static let leftMenuNavigationControllerIdentifier = "LeftMenuNavigationController"
    }
    
    struct NavigationControllerIdentifier {
        static let signUpNavigationController = "SignUpNavigationController"
        static let dashboardTabBarController = "DashboardTabBarViewController"
        static let insertItemNavigationController = "InsertItemNavigationController"
        static let listSettingsNavigationController = "ListSettingNavigationController"
        static let filterNavigationController = "FilterNavigationController"
        static let addReminderNavigationController = "AddReminderNavigationController"
    }
    
    struct TableViewCellIdentifier {
        static let listTableCell = "ListTableCell"
        static let editListNameTableCell = "EditListNameTableCell"
        static let listTypeTableCell = "ListTypeTableCell"
        static let recipeTableCell = "RecipeTableViewCell"
        static let itemSelectionTableCell = "ItemSelectionTableCell"
        static let moreSettingTypeTableViewCell = "MoreSettingTableViewCell"
        
    }
    
    enum TabBarControllerIndex: Int {
        case list = 0
        case recipe = 1
        case reminder = 2
        case setting = 3
        case upgrade = 4
    }
    
    struct ValidationMessages {
        struct name {
            static let tooLong = "Name cannot be more than \(InputLengthConstraints.Maximum.name) characters"
            static let empty = "Please enter the name"
            static let numeric = "Name cannot have numeric values"
            static let specialCharacters = "Name cannot have special characters"
            
        }
        
        struct category {
            static let emptyName = "Please enter the category name"
            static let alredayExists = "Category already exists"
            static let onlyAlphapets = "Category name contains only alphabets and spaces"
            
        }
        
        struct store {
            static let emptyName = "Please enter the store name"
            static let alreadyExists = "Store already exists"
            static let onlyAlphapets = "Store name contains only alphabets and spaces"
        }
        
        struct email {
            static let empy = "Please enter the email address"
            static let invalid = "Please enter a valid email address"
            static let exists = "The email address already exists"
        }
        
        struct password {
            static let confirm = "Please confirm your password"
            static let tooShort = "The password cannot be less than 6 characters"
            static let tooLong = "The password cannot be more than 20 characters"
        }
        
        static let loginFailed = "Login failed!"
        
        static let selectSport = "Please select sports first"
        static let noInternetConnection = "Check your internet connection"
        static let userName = "Please enter Username"
        static let enterName = "Please enter the name"
        static let enterValidName = "Please enter valid Name"
        static let enterScreenName = "Please enter Screen "
        static let enterEmail = "Please enter the email address"
        static let enterValidEmail = "Please enter a valid email address"
        static let enterUserName = "Please enter Username"
        static let enterCurrentPassword = "Please enter your current password"
        static let enterNewPassword = "Please enter the new password"
        static let enterPassword = "Please enter the password"
        static let enterConfirmPassword = "Please confirm your password"
        static let selectCategory = "Please select category"
        static let updateAlertMessage = "New version is available. Please update application"
        static let fillEmptyFields = "Please fill empty fields"
        static let fillListName = "Please enter the list name"
        static let validListName = "List name contains only alphabets, numbers and underscore"
        static let passwordMismatch = "Your new password and confirm password do not match"
        static let priceFilterWrong = "Min price can not be greater than Max price"
        
    }
    
    struct AlertMessage {
        static let passwordRecoveryMailSent = "A password reset message has been sent to the mail"
        static let loginFailed = "Login failed"
        static let signUpconfirmationMailSent = "A message with a confirmation link has been sent to your email address. Please follow the link to activate your account"
        static let listDeleteConfirmation = "Would you like to delete list?"
         static let listMultiDeleteConfirmation = "Would you like to delete selected lists?"
        static let reminderDeleteConfirmation = "Would you like to delete reminder?"
        static let storeDeleteConfirmation = "Would you like to delete store?"
        static let categoryDeleteConfirmation = "Would you like to delete category?"
        static let itemDeleteConfirmation = "Would you like to delete item?"
        static let allItemDeleteConfirmation = "Would you like to delete all items?"
        static let allItemUncrossConfirmation = "Would you like to mark as not purchased all items?"
        static let deleteCrossedItemConfirmation = "Would you like to delete all purchased items?"
        static let logoutConfirmation = "Are you sure you want to logout?"
        static let passwordNotSet = "Password can not be changed as you have logged in from social account."
        static let recipeNotAvailable = "Recipe does not exist, please refresh your data."
        static let checkInternetConnection =  "Check your internet connection"
        static let subscription =  "Please subscribe"
        static let permissionGrantMessage = "Please grant permission in Settings to continue using this service"
        static let subscriptionAlert = "Please upgrade to pro version"
        static let subscriptionAlertOpenRecipe = "You need to upgrade the account to pro version to view the recipe details"
    }
    
    struct AlertButtons {
        static let okButton = "Ok"
        static let cancelButton = "cancel"
    }
    
    struct ErrorMessages{
        static let noResultfound = "No result found"
        static let apiResponseFailed = "Api response failed"
    }
    struct StaticPagesType {
        static let termsOfService = "Terms of Service"
        static let privacyPolicy = "Privacy Policy"
        static let faq = "FAQ"
    }
    
    
    struct StringConstants{
        static let emptyMsg = "NA"
    }
    
    struct StatusCode{
        static let success = 200
        static let tokenExpire = 401
    }
   
    
    enum Storyboard:String {
        case dashboard = "Dashboard"
        case signUp = "SignUp"
        case list = "List"
        case recipe = "Recipe"
        case setting = "Setting"
        case reminder = "Reminder"
        case upgrade = "Upgrade"
        case reviewRating = "ReviewRating"
    }
    
    enum ApplicationNetworkErrorCodes: Int {
        case stateRestriction = 499
    }
    
}


struct KeychainKey {
    struct User {
        static let email = "email"
        static let firstName = "firstName"
        static let lastName = "lastName"
        static let providerId = "providerId"
        static let providerName = "providerName"
        static let token = "token"
    }
}

struct ExtraUrls {
    static let contactUs = "http://popularappsandgames.wordpress.com/contact/"
    static let privacyPolicy = "http://popularappsandgames.wordpress.com/privacy-policy/"
}
